﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;

namespace SimpleInserts
{
    class Program
    {
        static void Main(string[] args)
        {
            var settings = new MongoClientSettings
            {
                ReplicaSetName = "rs1",
                WriteConcern = new WriteConcern(w: 3, journal:true),
                WaitQueueTimeout = new TimeSpan(0, 0, 1000),
                ReadPreference = ReadPreference.Secondary,
            };
            var mongoClient = new MongoClient(settings);
            var db = mongoClient.GetDatabase("m101");
            var colletion = db.GetCollection<BsonDocument>("people");

            Console.WriteLine("Inserting");
            colletion.InsertOne(new BsonDocument { { "name", "Andrew Erlichson" }, { "favorite_color", "blue" } });
            Console.WriteLine("Inserting");
            colletion.InsertOne(new BsonDocument { { "name", "Richard Krueter" }, { "favorite_color","red" } });
            Console.WriteLine("Inserting");
            colletion.InsertOne(new BsonDocument { { "name", "Dwight Merriman" }, { "favorite_color", "green" } });
            Console.ReadLine();
        }
    }
}
