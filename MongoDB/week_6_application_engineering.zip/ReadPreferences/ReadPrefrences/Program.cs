﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ReadPrefrences
{
    class Program
    {
        static void Main(string[] args)
        {
            var settings = new MongoClientSettings
            {
                Servers = new List<MongoServerAddress>
                {
                    new MongoServerAddress("localhost", 27017),
                    new MongoServerAddress("localhost", 27018),
                    new MongoServerAddress("localhost", 27019)
                }
            };

            var mongoClient = new MongoClient(settings);
            var db = mongoClient.GetDatabase("m101");
            var colletion = db.GetCollection<BsonDocument>("things");

            for (int i = 0; i < 1000; i++)
            {
                var doc = colletion.FindAsync("{_id:" + i + "}").Result.FirstOrDefault();
                if (doc != null)
                    Console.WriteLine("Found doc " + doc);
                Thread.Sleep(100);
            }
        }
    }
}
