﻿using MongoDB.Bson;
using MongoDB.Driver;
using System;

namespace StressTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var mongoClient = new MongoClient();
            var db = mongoClient.GetDatabase("db");
            var colletion = db.GetCollection<BsonDocument>("students");

            for (int j = 0; j < 10; j++)
            {
                for (int i = 400001; i < 500000; i++)
                {
                    var doc = colletion.FindAsync("{student_id:" + i + "}").Result;
                    if (i % 1000 == 0)
                        Console.WriteLine("Did 1000 Searches");
                }
            }
        }
    }
}
